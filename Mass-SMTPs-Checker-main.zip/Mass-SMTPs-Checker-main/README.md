![image](https://github.com/user-attachments/assets/cfc63a58-a46d-4e2d-9eca-9195261a0c7b)
# Mass-SMTPs-Checker
 The Mass SMTPs Checker is a Python tool for verifying the functionality of multiple SMTP servers. It tests server connectivity, authentication, and email-sending capability, identifying valid and invalid SMTPs. Ideal for administrators managing bulk email setups or ensuring server reliability.
